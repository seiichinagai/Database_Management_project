Instructions on creating the database and setting up the web application:

DESCRIPTION:
This project is a movie database that keeps track of movies, directors, 
writers, actors, and genres.

To run this web application locally, the user must have Apache,
MySQL, and PHP running on their computer along with an operating
system (Windows, OS X, Linux, etc.).
If the user does not have this, please install before continuing.

DEPLOYMENT:
First, take movies.html and getmovieinfo.php files and place
them in the htdocs folder within the XAMPP folder.

Next, start Apache and MySQL.

Continuing, open a web browser and type localhost/phpmyadmin/ into 
the address bar. You now have to import the group11database sql file.

To import the sql file, you must first select import in the 
phpmyadmin tool. Next, choose the group11database.sql file by browsing
your computer. Once you have selected the file, select go in the 
phpmyadmin tool. The sql database is now available to use.

You can now begin to use the application. In your web browser, type
localhost/home.html. This will take you to the main application
page. From here you have multiple options. You can add a movie by
clicking Add Movie. You can also remove a movie by clicking 
Remove Movie. You can update Oscar wins for a movie by clicking
Update Movie. Finally, you can view pre-selected SQL select
statements. To view movies in the database that won Best Picture
at the Oscars, click View Best Picture. To view movies in the 
database that won Best Picture and Director at the Oscars, click
View Best Picture & Director. Finally, to view movies in the 
database that have no Oscar wins from any category, click View
No Wins.

When filling out the forms, please take not of the following:
Please enter the information you would like to add to all
databases. IMPORTANT Only click a select once all Movie ID boxes
have been filled in. Also, please make sure that any date of birth
you enter is in the correct YYYY-MM-DD (year-month-day) format as
not following this format will cause the DOB you enter to store as
0000-00-00. Lastly, the current database has movie IDs from 0 to
50 taken. Please enter a movie ID that is 51 or higher to avoid
error.

After you have submitted your data, you will be redirected to a page
which will confirm that the data you entered was processed. You will 
see  multiple tables which display all information contained in the 
database. This information is separated into movie, genre, writer, 
director, and leading actor. 

For your convenience, a Home button has been added to every page you
can visit with this application. To return to the home page, you can 
click that button anytime.

BUILT WITH:
HTML
PHP
MySQL

WRITTEN BY:
Brittany Fex, John Johnson, Sophia Yu, Seiichi Nagai